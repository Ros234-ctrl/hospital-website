
const cors = require('cors');

const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const express = require('express');

const app = express();
// Temporary admin account (add this before your login route)
const validAdmin = {
    username: "admin",
    password: "admin123" // Change this to something more secure
};

app.post('/api/admin/login', (req, res) => {
    const { username, password } = req.body;
    
    if (username === validAdmin.username && password === validAdmin.password) {
        res.json({ 
            success: true,
            token: "your_generated_jwt_token_here",
            message: "Login successful"
        });
    } else {
        res.status(401).json({
            success: false,
            error: "Invalid username or password"
        });
    }
});
app.use(cors());
app.use(express.json());

app.post('/api/admin/login', (req, res) => {
  res.json({ success: true, token: "test123" }); // TEST RESPONSE
});

app.listen(50002, () => console.log('SERVER IS 100% WORKING ON 50002'));
// Add these lines to allow connections from any frontend
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "*");
    next();
});

app.post('/api/admin/login', (req, res) => {
    res.json({ success: true }); // Test response
});

app.listen(50002, () => console.log("Running on http://localhost:50002"));
app.use(cors()); // Enable CORS
app.use(express.json());

app.post('/api/admin/login', (req, res) => {
    // Your login logic here
    res.json({ success: true, token: 'generated-token' });
});

app.listen(50002, '0.0.0.0', () => { // Listen on all network interfaces
    console.log('Server running on http://localhost:50002');
});

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/hospital_admin_db')
  .then(() => console.log("✅ Connected to MongoDB"))
  .catch(err => console.error("❌ MongoDB connection error:", err));

// Middleware
app.use(cors()); // Allow all origins for testing
app.use(express.json());

// Sample database (replace with real database connection)
const db = {
    admin_users: [
        {
            id: 1,
            username: "admin",
            password: bcrypt.hashSync("admin123", 10), // Hashed password
            role: "admin"
        }
    ],
    patients: [
        // Sample patient data structure matching your frontend
        {
            patientId: "P1001",
            fullName: "John Doe",
            age: 35,
            gender: "Male",
            contact: "john@example.com",
            bloodGroup: "O+",
            status: "Active"
        }
    ]
};

// Enable CORS middleware
app.use(cors({
    origin: 'http://localhost', // Or your frontend URL
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Body parser middleware
app.use(express.json());

// JWT Secret (should be in environment variables in production)
const JWT_SECRET = 'your_jwt_secret_key';

// Authentication middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) return res.sendStatus(401);
    
    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
}

// Login endpoint
app.post('/api/admin/login', (req, res) => {
    try {
        const { username, password } = req.body;
        const user = db.admin_users.find(u => u.username === username);
        
        if (!user || !bcrypt.compareSync(password, user.password)) {
            return res.status(401).json({
                success: false,
                error: "Invalid username or password"
            });
        }
        
        const token = jwt.sign(
            { userId: user.id, username: user.username, role: user.role },
            JWT_SECRET,
            { expiresIn: '1h' }
        );
        
        res.json({
            success: true,
            token: token,
            user: { username: user.username, role: user.role }
        });
        
    } catch (error) {
        console.error("Login error:", error);
        res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
});

// Patients endpoints
app.get('/api/patients', authenticateToken, (req, res) => {
    try {
        res.json({
            success: true,
            data: db.patients,
            stats: { // Sample stats matching your frontend
                total: db.patients.length,
                active: db.patients.filter(p => p.status === 'Active').length,
                emergency: db.patients.filter(p => p.status === 'Emergency').length
            }
        });
    } catch (error) {
        console.error("Error fetching patients:", error);
        res.status(500).json({
            success: false,
            error: "Failed to fetch patients"
        });
    }
});

app.post('/api/patients', authenticateToken, (req, res) => {
    try {
        const newPatient = {
            patientId: 'P' + Math.floor(1000 + Math.random() * 9000),
            ...req.body
        };
        db.patients.push(newPatient);
        res.json({
            success: true,
            data: newPatient
        });
    } catch (error) {
        console.error("Error adding patient:", error);
        res.status(500).json({
            success: false,
            error: "Failed to add patient"
        });
    }
});

app.get('/api/patients/:id', authenticateToken, (req, res) => {
    try {
        const patient = db.patients.find(p => p.patientId === req.params.id);
        if (!patient) {
            return res.status(404).json({
                success: false,
                error: "Patient not found"
            });
        }
        res.json({
            success: true,
            data: patient
        });
    } catch (error) {
        console.error("Error fetching patient:", error);
        res.status(500).json({
            success: false,
            error: "Failed to fetch patient"
        });
    }
});

app.put('/api/patients/:id', authenticateToken, (req, res) => {
    try {
        const index = db.patients.findIndex(p => p.patientId === req.params.id);
        if (index === -1) {
            return res.status(404).json({
                success: false,
                error: "Patient not found"
            });
        }
        
        db.patients[index] = { ...db.patients[index], ...req.body };
        res.json({
            success: true,
            data: db.patients[index]
        });
    } catch (error) {
        console.error("Error updating patient:", error);
        res.status(500).json({
            success: false,
            error: "Failed to update patient"
        });
    }
});

app.delete('/api/patients/:id', authenticateToken, (req, res) => {
    try {
        const index = db.patients.findIndex(p => p.patientId === req.params.id);
        if (index === -1) {
            return res.status(404).json({
                success: false,
                error: "Patient not found"
            });
        }
        
        db.patients.splice(index, 1);
        res.json({
            success: true,
            message: "Patient deleted successfully"
        });
    } catch (error) {
        console.error("Error deleting patient:", error);
        res.status(500).json({
            success: false,
            error: "Failed to delete patient"
        });
    }
});

// Start server
app.listen(50002, () => {
    console.log("Server running on http://localhost:50002");
});