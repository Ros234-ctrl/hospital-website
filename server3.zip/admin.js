let authToken = null;
let patientsTable;

$(document).ready(function() {
    // Show login modal first
    const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
    loginModal.show();

    // Initialize DataTable
    patientsTable = $('#patientsTable').DataTable({
        columns: [
            { data: 'patientId' },
            { data: 'fullName' },
            { data: 'age' },
            { data: 'gender' },
            { data: 'contact' },
            { data: 'bloodGroup' },
            { 
                data: 'status',
                render: function(data, type, row) {
                    let badgeClass = 'bg-secondary';
                    if (data === 'Active') badgeClass = 'bg-success';
                    if (data === 'Emergency') badgeClass = 'bg-danger';
                    return `<span class="badge ${badgeClass}">${data}</span>`;
                }
            },
            {
                data: null,
                render: function(data, type, row) {
                    return `
                        <button class="btn btn-sm btn-outline-primary edit-btn" data-id="${row._id}">
                            <i class="bi bi-pencil-square"></i>
                        </button>
                    `;
                },
                orderable: false
            }
        ]
    });

    // Login functionality
    $('#loginBtn').click(function() {
        const username = $('#username').val();
        const password = $('#password').val();

        $.ajax({
            url: 'http://localhost:4000/api/admin/login',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ username, password }),
            success: function(response) {
                if (response.success) {
                    authToken = response.token;
                    $('#loginModal').modal('hide');
                    loadPatients();
                } else {
                    alert('Login failed: ' + response.error); 
                }
            },
            error: function(xhr) {
                alert('Error connecting to server');
            }
        });
    });

    // Load patients data
    function loadPatients() {
        $.ajax({
            url: 'http://localhost:4000/api/patients',
            method: 'GET',
            headers: { 'Authorization': `Bearer ${authToken}` },
            success: function(response) {
                if (response.success) {
                    patientsTable.clear().rows.add(response.data).draw();
                }
            },
            error: function(xhr) {
                if (xhr.status === 401) {
                    alert('Session expired. Please login again.');
                    loginModal.show();
                }
            }
        });
    }

    // Other functions (export, add/edit/delete patients) remain the same
    // ...
});
